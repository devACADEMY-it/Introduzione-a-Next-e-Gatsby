import React, {useState, useEffect} from "react";
import BaseLayout from "../components/layout/BaseLayout";
import PostList from "../components/PostList";

export default function Home() {
  const [posts, setPosts] = useState([]);

  useEffect(() => {
    const getPosts = async () => {
      try {
        const res = await fetch('https://jsonplaceholder.typicode.com/posts?_limit=9');
        const json = await res.json();
        setPosts(json);
      } catch(error) {
        console.log(error);
      }
    };

    getPosts();
  });

  return (
    <BaseLayout>
      <h1 className="title">Blog</h1>
      <PostList data={posts} />
    </BaseLayout>
  )
}
