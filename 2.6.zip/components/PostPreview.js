import React from 'react';

export default function PostPreview({item}) {
  return (
    <div className="card">
      <div className="card-content">
        <div className="media">
          <div className="media-content">
            <p className="title is-4">Post</p>
            <p className="subtitle is-6">User ID: {item.userId}</p>
          </div>
        </div>

        <div className="content">
          <p>{item.title}</p>
        </div>
      </div>
    </div>
  )
}
