import React from "react";
import BaseLayout from "../components/layout/BaseLayout";

export default function Home() {
  return (
    <BaseLayout>
      <h1 className="title">Blog</h1>
    </BaseLayout>
  )
}
