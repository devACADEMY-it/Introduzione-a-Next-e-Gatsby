import React from "react"
import Navbar from "../../components/Navbar"

export default function Container({children}) {
  return (
    <div className="container is-fluid">
      <div className="section">
        <h1 className="title is-1">Carmhack Blog</h1>
        <h2 className="subtitle is-2">A blog about programming</h2>
        <Navbar />

        {children}
      </div>
    </div>
  )
}
