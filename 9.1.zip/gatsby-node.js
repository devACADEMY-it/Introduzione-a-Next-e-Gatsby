const path = require('path');

exports.createPages = async ({ actions, graphql }) => {
  const { createPage } = actions;

  const result = await graphql(`
    {
      allMarkdownRemark {
        edges {
          node {
            frontmatter {
              path
            }
          }
        }
      }
    }
  `);

  if (result.errors) {
    console.log(result.errors);
  }

  result.data.allMarkdownRemark.edges.forEach(({ node }) => {
    createPage({
      path: node.frontmatter.path,
      component: path.resolve(`src/templates/post/post.js`),
    })
  })

  const allPosts = await graphql(`
    {
      allMarkdownRemark(
        sort: { fields: [frontmatter___date], order: DESC }
        limit: 1000
      ) {
        edges {
          node {
            frontmatter {
              path
            }
          }
        }
      }
    }
  `)

  const posts = allPosts.data.allMarkdownRemark.edges;
  const perPage = 2;
  const numPages = Math.ceil(posts.length / perPage);
  posts.forEach((post, i) => {
    createPage({
      path: i === 0 ? '/blog' : `/blog/${i+1}`,
      component: path.resolve('./src/templates/post-list.js'),
      context: {
        limit: perPage,
        skip: i * perPage,
        numPages,
        currentPage: i + 1,
      }
    })
  })
}
