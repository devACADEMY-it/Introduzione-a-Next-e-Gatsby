import React from 'react';
import { Link } from "gatsby"

export default function PostPreview({item}) {
  const { title, subtitle, path } = item;

  return (
    <article className="message is-dark">
      <div className="message-body">
        <h1 className="title is-4">{title}</h1>
        <h2 className="subtitle is-5">{subtitle}</h2>
        <Link to={path}><button className="button is-small is-dark is-outlined">Leggi</button></Link>
      </div>
    </article>
  )
}
