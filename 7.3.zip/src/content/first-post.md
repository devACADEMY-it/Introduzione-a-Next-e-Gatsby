---
title: First Post
date: 09-06-2020
path: /first-post
author: carmhack
---

<h2 class="subtitle is-4">CIAO NUOVO TITOLO</h2>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam quis sapien sollicitudin, porttitor turpis et, placerat urna. Vivamus pulvinar eget felis vitae accumsan. Fusce volutpat, neque et porta iaculis, libero velit semper augue, nec iaculis orci quam sed libero. Donec laoreet purus sapien, et viverra nunc gravida sit amet. Curabitur vitae justo lorem. Nunc ullamcorper ornare augue id dictum. Mauris risus elit, semper ac felis non, ullamcorper mollis arcu. In hac habitasse platea dictumst. Donec non risus justo. Maecenas magna felis, imperdiet quis felis at, rhoncus tristique mi.
