import React from "react"
import { graphql } from "gatsby"
import { Link } from "gatsby"
import Container from "../../layouts/container"

export default function Post({data}) {
  const { markdownRemark } = data;
  const { html, frontmatter } = markdownRemark;

  return (
    <Container>
      <Link to="/"><button className="button is-primary is-small" style={{marginBottom: '20px'}}>Torna alla home</button></Link>
      <p>Scritto il <strong>{frontmatter.date}</strong> da <strong>{frontmatter.author}</strong></p>
      <h1 className="title is-2">{frontmatter.title}</h1>
      <h2 className="subtitle is-3">{frontmatter.subtitle}</h2>
      <div className="content" dangerouslySetInnerHTML={{ __html: html }}></div>
    </Container>
  )
}

export const pageQuery = graphql`
  query($path: String!) {
    markdownRemark(frontmatter: { path: { eq: $path }}) {
      html
      frontmatter {
        author
        path
        date
        title
        subtitle
      }
    }
  }
`
