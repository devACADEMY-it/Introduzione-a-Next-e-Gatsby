const ENDPOINT = 'https://jsonplaceholder.typicode.com/posts';

export default async (req, res) => {
  const method = req.method;
  if (method === 'GET') {
    const query = req.query;
    const { _limit } = query;
    try {
      const result = await fetch(`${ENDPOINT}?_limit=${_limit}`);
      res.statusCode = 200;
      const posts = await result.json();
      res.json(posts);
    } catch(error) {
      console.log(error);
    }
  }
}
