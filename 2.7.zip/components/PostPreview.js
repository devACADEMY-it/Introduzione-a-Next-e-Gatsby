import React from 'react';

export default function PostPreview({item}) {
  return (
    <div className="card">
      <header className="card-header">
        <p className="card-header-title">Post Preview</p>
      </header>
      <div className="card-content" style={{minHeight: 120}}>
        <div className="media">
          <div className="media-left">
            <figure className="image is-48x48">
              <img src="/postPlaceholder.png" alt="Placeholder image" />
            </figure>
          </div>
          <div className="media-content">
            <p>{item.title}</p>
          </div>
        </div>
      </div>
      <footer className="card-footer">
        <a className="card-footer-item">Dettaglio</a>
      </footer>
    </div>
  )
}
