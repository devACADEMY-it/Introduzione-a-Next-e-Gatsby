import React from "react"

export default function Home() {
  return (
    <div>
      <h1>Carmhack Blog</h1>
    </div>
  )
}
