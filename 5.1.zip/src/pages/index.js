import React from "react"

export default function Home() {
  return <div>Hello world!</div>
}
