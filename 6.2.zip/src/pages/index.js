import React from "react"
import Post from "../../components/post/post"

export default function Home() {
  return (
    <div>
      <Post />
      <p className="post-title">Nuovo titolo</p>
    </div>
  )
}
