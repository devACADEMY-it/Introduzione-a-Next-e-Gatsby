import Head from 'next/head'

export default function Home() {
  return (
    <div className="container">
      <Head>
        <title>Carmhack Blog</title>
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <div className="section">
        <h1 className="title">
          Carmhack Blog
        </h1>
      </div>
    </div>
  )
}
