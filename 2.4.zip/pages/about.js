import React from 'react';
import Head from "next/dist/next-server/lib/head";
import Navbar from "../components/Navbar";

export default function About() {
  return (
    <div className="container">
      <div className="section">
        <Navbar />

        <h1 className="title">About</h1>
      </div>
    </div>
  )
}
