import Head from 'next/head'
import Navbar from "../components/Navbar";
import React from "react";

export default function Home() {
  return (
    <div className="container">
      <Head>
        <title>Carmhack Blog</title>
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <div className="section">
        <Navbar />

        <h1 className="title">Blog</h1>
      </div>
    </div>
  )
}
