export const API = `https://devacademy-next-blog.now.sh/api`;
export const ENDPOINT = {
  POSTS: 'posts',
  USERS: 'users',
};
