import Cors from 'micro-cors';

const cors = Cors({
  allowedMethods: ['GET']
});

const BASE_URL = 'https://jsonplaceholder.typicode.com/users';

const UserEndpoint = async (req, res) => {
  const method = req.method;
  if (method === 'GET') {
    const query = req.query;
    const { id } = query;

    try {
      const result = await fetch(`${BASE_URL}/${id}`);
      const user = await result.json();
      res.statusCode = 200;
      res.json(user);
    } catch(error) {
      console.log(error);
    }
  }
};

export default cors(UserEndpoint);
