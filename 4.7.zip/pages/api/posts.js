import Cors from 'micro-cors';

const cors = Cors({
  allowedMethods: ['GET']
});

const BASE_URL = 'https://jsonplaceholder.typicode.com/posts';
const LIMIT = 9;

const PostEndpoint = async (req, res) => {
  const method = req.method;
  if (method === 'GET') {
    const query = req.query;
    const { _start } = query;
    try {
      const result = await fetch(`${BASE_URL}?_start=${_start}&_limit=${LIMIT}`);
      res.statusCode = 200;
      const posts = await result.json();
      res.json(posts);
    } catch(error) {
      console.log(error);
    }
  }
};

export default cors(PostEndpoint);
