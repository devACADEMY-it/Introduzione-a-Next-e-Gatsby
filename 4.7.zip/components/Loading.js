import React from 'react';

export default function Loading() {
  return (
    <h2 className="subtitle is-4">Loading...</h2>
  )
}
