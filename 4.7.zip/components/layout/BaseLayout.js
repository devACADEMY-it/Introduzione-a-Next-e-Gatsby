import React from 'react';
import Navbar from "../Navbar";
import Head from "next/head";

export default function BaseLayout({ children }) {
  return (
    <div className="container">
      <Head>
        <title>Carmhack Blog</title>
      </Head>
      <div className="section">
        <Navbar />

        {children}
      </div>
    </div>
  )
}
