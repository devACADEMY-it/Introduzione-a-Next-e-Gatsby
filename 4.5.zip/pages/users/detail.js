import React from 'react';

export default function Detail() {
  return (
    <h1 className="title">User</h1>
  )
}
