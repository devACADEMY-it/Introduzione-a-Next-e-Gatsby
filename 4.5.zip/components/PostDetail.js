import React, {useState, useEffect} from 'react';
import {API, ENDPOINT} from "../constants/api";
import Link from "next/link";

export default function PostDetail({item = {}}) {
  const [username, setUsername] = useState('');
  useEffect(() => {
    const getUser = async () => {
      try {
        const res = await fetch(`https://jsonplaceholder.typicode.com/${ENDPOINT.USERS}/${item.userId}`);
        const json = await res.json();
        setUsername(json.username);
      } catch(error) {
        console.log(error);
      }
    };

    getUser();
  }, [item]);

  return (
    <div className="card">
      <header className="card-header">
        <p className="card-header-title">{item.title}</p>
      </header>
      <div className="card-content" style={{minHeight: 120}}>
        <div className="media">
          <div className="media-left">
            <figure className="image is-48x48">
              <img src="/postPlaceholder.png" alt="Placeholder image" />
            </figure>
          </div>
          <div className="media-content">
            <p>{item.body}</p>
          </div>
        </div>
        <Link href="/users/detail">
          <p className="subtitle is-6">Scritto da {username}</p>
        </Link>
      </div>
    </div>
  )
}
