import React from "react"
import Post from "../templates/post/post"

export default function Home() {
  return (
    <div>
      <Post />
    </div>
  )
}
