import React from "react"
import Container from "../layouts/container"
import PostList from "../../components/PostList"

export default function Home() {
  return (
    <Container>
      <h1 className="title is-2">Carmhack Blog</h1>

      <PostList />
    </Container>
  )
}
