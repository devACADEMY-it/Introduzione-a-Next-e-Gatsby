import React from "react"
import { graphql } from "gatsby"
import postStyle from "./post.module.css"

export default function Post({data}) {
  const { markdownRemark } = data;
  const { html, frontmatter } = markdownRemark;

  return (
    <div className="card">
      <header className="card-header">
        <p className={postStyle.postTitle}>{frontmatter.title}</p>
        <p className="subtitle is-6">{frontmatter.date}</p>
      </header>
      <div className="card-content">
        <div className="content" dangerouslySetInnerHTML={{ __html: html }}></div>
      </div>
      <footer className="card-footer">
        <a className="card-footer-item">Dettaglio</a>
      </footer>
    </div>
  )
}

export const pageQuery = graphql`
  query($path: String!) {
    markdownRemark(frontmatter: { path: { eq: $path }}) {
      html
      frontmatter {
        author
        path
        date
        title
      }
    }
  }
`
