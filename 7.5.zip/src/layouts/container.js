import React from "react"

export default function Container({children}) {
  return (
    <div className="container is-fluid">
      <div className="section">
        {children}
      </div>
    </div>
  )
}
