import React, {useState, useEffect} from "react";
import BaseLayout from "../components/layout/BaseLayout";
import PostList from "../components/PostList";

export default function Home() {
  const [posts, setPosts] = useState([]);
  const [offset, setOffset] = useState(0);

  useEffect(() => {
    const getPosts = async () => {
      try {
        const res = await fetch(`http://localhost:3000/api/posts?_start=${offset}`);
        const json = await res.json();
        setPosts(json);
      } catch(error) {
        console.log(error);
      }
    };

    getPosts();
  }, [offset]);

  const onPrev = () => {
    const newOffset = offset - 9;
    if (newOffset >= 0) {
      setOffset(newOffset);
    }
  };

  const onNext = () => {
    setOffset(offset + 9);
  };

  return (
    <BaseLayout>
      <h1 className="title">Blog</h1>
      <div className="buttons">
        <button className="button is-info" onClick={onPrev}>Prev</button>
        <button className="button is-info" onClick={onNext}>Next</button>
      </div>
      <PostList data={posts} />
    </BaseLayout>
  )
}
