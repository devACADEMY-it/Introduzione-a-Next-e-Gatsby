import React from 'react';
import PostPreview from "./PostPreview";

export default function PostList({ data }) {
  return (
    <div className="columns is-multiline">
      {
        data.map(item =>
          <div key={item.id} className="column is-4">
            <PostPreview item={item} />
          </div>
        )
      }
    </div>
  )
}
