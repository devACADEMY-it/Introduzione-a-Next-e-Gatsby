export const API = `http://localhost:3000/api`;
export const ENDPOINT = {
  POSTS: 'posts',
};
