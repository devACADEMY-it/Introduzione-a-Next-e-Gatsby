import React from 'react';

export default function PostDetail({item = {}}) {
  return (
    <div className="card">
      <header className="card-header">
        <p className="card-header-title">{item.title}</p>
      </header>
      <div className="card-content" style={{minHeight: 120}}>
        <div className="media">
          <div className="media-left">
            <figure className="image is-48x48">
              <img src="/postPlaceholder.png" alt="Placeholder image" />
            </figure>
          </div>
          <div className="media-content">
            <p>{item.body}</p>
          </div>
        </div>
      </div>
    </div>
  )
}
