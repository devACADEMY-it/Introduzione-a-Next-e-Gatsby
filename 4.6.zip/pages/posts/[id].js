import React from 'react';
import {useRouter} from "next/router";
import PostDetail from "../../components/PostDetail";
import BaseLayout from "../../components/layout/BaseLayout";

export default function Post({item}) {
  const router = useRouter();
  const {id} = router.query;

  return (
    <BaseLayout>
      <h1 className="title">Post {id}</h1>
      <PostDetail item={item} />
    </BaseLayout>
  )
}

export async function getStaticProps({params}) {
  let json = {};
  try {
    const res = await fetch(`https://jsonplaceholder.typicode.com/posts/${params.id}`);
    json = await res.json();
  } catch(error) {
    console.log(error);
  }

  return {
    props: {
      item: json
    }
  }
}

export async function getStaticPaths() {
  let paths = [];
  try {
    const res = await fetch('https://jsonplaceholder.typicode.com/posts?_limit=9');
    const json = await res.json();
    paths = json.map(item => {
      return {
        params: { id: item.id.toString() }
      }
    })
  } catch(error) {
    console.log(error);
  }

  return {
    paths,
    fallback: true,
  }
}

