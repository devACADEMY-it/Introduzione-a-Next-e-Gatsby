import React, {useState, useEffect} from 'react';
import {useRouter} from "next/router";
import BaseLayout from "../../components/layout/BaseLayout";
import {API, ENDPOINT} from "../../constants/api";

export default function User() {
  const router = useRouter();
  const [user, setUser] = useState({});
  const {id} = router.query;

  useEffect(() => {
    const getUser = async () => {
      try {
        const res = await fetch(`${API}/${ENDPOINT.USERS}/${id}`);
        const json = await res.json();
        setUser(json);
      } catch(error) {
        console.log(error);
      }
    };

    if (id) {
      getUser();
    }
  }, [id]);

  return (
    <BaseLayout>
      <h1 className="title">{user.name}</h1>
    </BaseLayout>
  )
}
