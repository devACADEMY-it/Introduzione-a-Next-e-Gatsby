import React from "react"
import { Link, graphql } from "gatsby"
import Container from "../../layouts/container"
import PostPreview from "../../../components/PostPreview"

export default function PostList({data}) {
  const { allMarkdownRemark } = data;
  const { pageInfo } = allMarkdownRemark

  const getPreviousPath = () => {
    let toRet = '/blog'
    const { currentPage } = pageInfo;
    if (currentPage > 2) {
      toRet = `/blog/${currentPage - 1}`
    }
    return toRet;
  }

  return (
    <Container>
      <h2 className="subtitle is-3 has-text-weight-light">Elenco dei post</h2>
      {
        allMarkdownRemark.edges.map(({node}) => <PostPreview key={node.frontmatter.path} item={node.frontmatter} />)
      }
      <div className="level">
        <div className="level-left">
          <div className="level-item">
            {
              pageInfo.hasPreviousPage && <Link to={getPreviousPath()}><button className="button is-info is-outlined">Indietro</button></Link>
            }
          </div>
        </div>
        <div className="level-right">
          <div className="level-item">
            {
              pageInfo.hasNextPage && <Link to={`/blog/${pageInfo.currentPage+1}`}><button className="button is-info is-outlined">Avanti</button></Link>
            }
          </div>
        </div>
      </div>
    </Container>
  )
}

export const pageQuery = graphql`
  query($skip: Int!, $limit: Int!) {
    allMarkdownRemark(
      sort: { fields: [frontmatter___date], order: DESC}
      limit: $limit
      skip: $skip
    ) {
      edges {
        node {
          frontmatter {
            title
            subtitle
            path
          }
        }
      }
      pageInfo {
        currentPage
        hasNextPage
        hasPreviousPage
      }
    }
  }
`
