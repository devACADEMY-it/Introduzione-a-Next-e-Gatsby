import React from 'react';
import { Link } from "gatsby";
import navbarStyle from "./navbar.module.css";

export default function Navbar() {
  return (
    <nav className="breadcrumb has-bullet-separator" aria-label="breadcrumbs">
      <ul>
        <li><Link to="/"><span className={navbarStyle.link}>Home</span></Link></li>
        <li><Link to="/blog"><span className={navbarStyle.link}>Blog</span></Link></li>
        <li><Link to="/about"><span className={navbarStyle.link}>About</span></Link></li>
      </ul>
    </nav>
  )
}
