import React from 'react';

export default function PostPreview({item}) {
  const { title, subtitle } = item;

  return (
    <article className="message is-dark">
      <div className="message-body" style={{minHeight: 150}}>
        <h1 className="title is-4">{title}</h1>
        <h2 className="subtitle is-6">{subtitle}</h2>
      </div>
    </article>
  )
}
