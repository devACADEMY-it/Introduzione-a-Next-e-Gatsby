import React from 'react';
import PostPreview from "./PostPreview"

export default function PostList({data}) {
  return (
    <div className="columns is-multiline">
      {
        data.map(({ node }) =>
          <div className="column is-4" key={node.frontmatter.path}>
            <PostPreview item={node.frontmatter}></PostPreview>
          </div>
        )
      }
    </div>
  )
}
