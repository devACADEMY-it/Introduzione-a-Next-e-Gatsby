import React from 'react';
import AniLink from "gatsby-plugin-transition-link/AniLink";
import navbarStyle from "./navbar.module.css";

export default function Navbar() {
  return (
    <nav className="breadcrumb has-bullet-separator" aria-label="breadcrumbs">
      <ul>
        <li>
          <AniLink
            paintDrip
            color="grey"
            duration={0.5}
            to="/"
          >
            <span className={navbarStyle.link}>Home</span>
          </AniLink>
        </li>
        <li>
          <AniLink
            swipe
            direction="up"
            duration={0.5}
            to="/blog"
          >
            <span className={navbarStyle.link}>Blog</span>
          </AniLink>
        </li>
        <li>
          <AniLink
            paintDrip
            color="grey"
            duration={0.5}
            to="/about"
          >
            <span className={navbarStyle.link}>About</span>
          </AniLink>
        </li>
      </ul>
    </nav>
  )
}
