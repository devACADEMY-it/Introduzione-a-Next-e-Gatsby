import React from 'react';
import { Link } from "gatsby"

export default function PostPreview({item}) {
  const { title, subtitle, date, path } = item;

  return (
    <article className="message is-dark">
      <div className="message-body">
        <small>{date}</small>
        <h1 className="title is-4">{title}</h1>
        <h2 className="subtitle is-5">{subtitle}</h2>
        <Link to={path}><button className="button is-small is-dark is-outlined">Leggi</button></Link>
      </div>
    </article>
  )
}
