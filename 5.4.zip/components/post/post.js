import React from 'react';
import postStyle from "./post.module.css"

export default function Post() {
  return (
    <div className="card">
      <header className="card-header">
        <p className={postStyle.postTitle}>Titolo</p>
      </header>
      <div className="card-content">
        <div className="content">
          Contenuto
        </div>
      </div>
      <footer className="card-footer">
        <a className="card-footer-item">Dettaglio</a>
      </footer>
    </div>
  )
}
