import React from 'react';

export default function PostList({data}) {
  return (
    <>
      <h2 className="subtitle is-4">Ultimi post</h2>
      {
        data.map(({ node }) => <p>{node.frontmatter.title}</p>)
      }
    </>
  )
}
