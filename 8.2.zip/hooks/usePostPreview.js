import { useStaticQuery, graphql } from "gatsby"

export const usePostPreview = () => {
  const { allMarkdownRemark } = useStaticQuery(

  )
  return allMarkdownRemark.edges
}
