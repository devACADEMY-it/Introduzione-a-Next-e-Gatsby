import React from 'react';
import PostPreview from "./PostPreview"

export default function PostList({data}) {
  return (
    <>
      {
        data.map(({ node }) => <PostPreview key={node.frontmatter.path} item={node.frontmatter}></PostPreview>)
      }
    </>
  )
}
