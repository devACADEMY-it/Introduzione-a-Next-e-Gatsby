import { useStaticQuery, graphql } from "gatsby"

export const usePostPreview = () => {
  const { allMarkdownRemark } = useStaticQuery(graphql`
    query GetPostPreview {
      allMarkdownRemark(sort: { fields: [frontmatter___date], order:DESC}, limit:3) {
        edges {
          node {
            frontmatter {
              title
              subtitle
              date
            }
          }
        }
      }
    }
  `)
  return allMarkdownRemark.edges
}
