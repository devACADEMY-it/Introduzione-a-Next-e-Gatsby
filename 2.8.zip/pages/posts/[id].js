import React, {useState, useEffect} from 'react';
import {useRouter} from "next/router";
import PostDetail from "../../components/PostDetail";
import BaseLayout from "../../components/layout/BaseLayout";

export default function Post() {
  const [item, setItem] = useState({});
  const router = useRouter();
  const {id} = router.query;

  useEffect(() => {
    const getPostDetail = async () => {
      try {
        const res = await fetch(`https://jsonplaceholder.typicode.com/posts/${id}`);
        const json = await res.json();
        setItem(json);
      } catch(error) {
        console.log(error);
      }
    };

    if (id) {
      getPostDetail();
    }
  }, [id]);

  return (
    <BaseLayout>
      <h1 className="title">Post {id}</h1>
      <PostDetail item={item} />
    </BaseLayout>
  )
}
