import React, {useState, useEffect} from 'react';
import {useRouter} from "next/router";
import PostDetail from "../../components/PostDetail";
import BaseLayout from "../../components/layout/BaseLayout";

export default function Post({item}) {
  const router = useRouter();
  const {id} = router.query;

  return (
    <BaseLayout>
      <h1 className="title">Post {id}</h1>
      <PostDetail item={item} />
    </BaseLayout>
  )
}

export async function getStaticProps() {
  let json = {};
  try {
    const res = await fetch(`https://jsonplaceholder.typicode.com/posts/1`);
    json = await res.json();
  } catch(error) {
    console.log(error);
  }

  return {
    props: {
      item: json
    }
  }
}

