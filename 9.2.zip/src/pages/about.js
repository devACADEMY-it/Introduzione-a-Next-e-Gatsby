import React from "react"
import Container from "../layouts/container"
import MyImage from "../assets/me.jpg";

export default function About() {
  return (
    <Container>
      <div className="columns">
        <div className="column is-3">
          <figure className="image is-128x128" style={{margin: '20px auto'}}>
            <img className="is-rounded" src={MyImage} alt="Carmhack" />
          </figure>
        </div>
        <div className="column">
          <p className="content">
            Sviluppatore web specializzato nello sviluppo front-end. Fin da ragazzo ha diverse passioni: la lettura, la musica, i film. Ma è la programmazione a prendere il sopravvento, in particolar modo nel 2010, quando inizia ad avvicinarsi alla programmazione web.
            Nel 2012 decide di creare sulla piattaforma YouTube un canale (Carmhack) dedicato alla programmazione, proponendo tutorial su diversi linguaggi di programmazione (C, Java, Python, JavaScript, HTML / CSS, WordPress, etc.), seguendo di pari passo la sua formazione professionale e le richieste degli utenti. Attualmente conta oltre 2 milioni di visualizzazioni e oltre 10 mila iscritti).
            Nel 2018, lavorando già da qualche anno nel settore come freelance, si laurea alla Facoltà di Informatica dell’Università degli Studi di Salerno con una tesi sui sistemi di raccomandazione in Python.
            Attualmente lavora come sviluppatore front-end e utilizza alcuni dei framework front-end più utilizzati come Vue.js, React ed Angular.
          </p>
        </div>
      </div>
    </Container>
  )
}
