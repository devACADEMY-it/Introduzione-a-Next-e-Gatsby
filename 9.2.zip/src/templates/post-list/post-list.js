import React from "react"
import { graphql } from "gatsby"
import Container from "../../layouts/container"
import PostPreview from "../../../components/PostPreview"

export default function PostList({data}) {
  const { allMarkdownRemark } = data;

  return (
    <Container>
      {
        allMarkdownRemark.edges.map(({node}) => <PostPreview key={node.frontmatter.path} item={node.frontmatter} />)
      }
    </Container>
  )
}

export const pageQuery = graphql`
  query($skip: Int!, $limit: Int!) {
    allMarkdownRemark(
      sort: { fields: [frontmatter___date], order: DESC}
      limit: $limit
      skip: $skip
    ) {
      edges {
        node {
          frontmatter {
            title
            subtitle
            path
          }
        }
      }
    }
  }
`
